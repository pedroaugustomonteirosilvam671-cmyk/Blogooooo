namespace BLOGGGG.model
{
    using system;
    using system.Collections.Gerenric;

    public class Publicacao
    {
        public Guid Id { get; set; } = Guid.NewGuid();
        public string Titulo { get; set; } = string.Empty;
        public string Conteudo { get; set; } = string.Empty;
        public DateTime DataCriacao { get; set; } = DateTime.Now;
        public Usuario Autor { get; set; } = new Usuario();
        public List<Comentario> Comentarios { get; set; } = new List<Comentario>();
    }
}