﻿namespace App.Data
{
using system;
using MySqlConnector;

public class conexao
{
    private readoly string _connectionString;

    public conexao()
    {
        _connectionString = LerVariavel("DB_CONNECTION_STRING");
    }

    public MySqlConnection CriarConexao()
    {
    return new MySqlConnection(_connectionString);
    }
    
    private string LerVariavel
    {
                         return Environment.GetEnvironmentVariable(nomeVariavel) 
                   ?? "Server=localhost;Database=BLOG caso de uso;User ID=root;Password=root;Port=3308;";
    }
  }
}



