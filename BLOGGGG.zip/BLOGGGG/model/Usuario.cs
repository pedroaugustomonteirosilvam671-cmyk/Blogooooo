namespace BLOGGGG.model
{
    using system;

    public class Usuario 
    {
        public Guid ID { get; set; } = Guid.NewGuid();
        public string Nome { get; set; } = string.Empty;
        public string Email { get; set; } = string.Empty;
        public DateTime DataCriacao { get; set; } = DateTime.Now;
    }
}